﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace raschetbenzina
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double km = Double.Parse(textBox1.Text);
            double l = Double.Parse(textBox2.Text);

            double r = l / km * 100;

            rashod.Text = Convert.ToString(r);
        }
    }
}
