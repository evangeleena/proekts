﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pokupkaavtomobilya
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            name.Text = "Skoda Rapid";
            foto.Image = Image.FromFile(@"C:\Users\evang\source\repos\pokupkaavtomobilya\pokupkaavtomobilya\img\rapid.jpg");
            cena.Text = "1 500 000";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            name.Text = "Skoda Octavia";
            foto.Image = Image.FromFile(@"C:\Users\evang\source\repos\pokupkaavtomobilya\pokupkaavtomobilya\img\octavia.jpg");
            cena.Text = "2 000 000";
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            name.Text = "Skoda Superb";
            foto.Image = Image.FromFile(@"C:\Users\evang\source\repos\pokupkaavtomobilya\pokupkaavtomobilya\img\superb.jpg");
            cena.Text = "3 500 000";
        }
    }
}
